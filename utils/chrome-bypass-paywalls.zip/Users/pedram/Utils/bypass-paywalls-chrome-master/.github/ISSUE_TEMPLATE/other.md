---
name: Other
about: Other issues (site not working, bugs, etc)
title: ''
labels: ''
assignees: ''

---


###
1. First search [Issues](https://github.com/iamadamdev/bypass-paywalls-chrome/issues) to see if your problem has already been reported.
2. Make sure uBlock Origin is installed.
3. Chrome or Firefox?
4. Paste the article URL for the site you are having issues with.
5. Describe the issue.
###
